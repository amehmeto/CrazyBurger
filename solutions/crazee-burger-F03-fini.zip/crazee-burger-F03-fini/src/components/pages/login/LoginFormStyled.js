import styled from "styled-components"

export const LoginFormStyled = styled.form`
  border: 1px solid blue;

  h1 {
    font-size: 40px;
    color: red;
    background-color: green;
  }

  .alex {
  }

  .bonbon {
    background-color: pink;
    font-size: 18px;
  }

  button {
    background-color: orange;
  }
`
